# m001-paper-fan-personal

可修改的独立动效工程：1920×1080，30fps，6.2秒，无音轨。

1. 编辑 `config.json`，替换姓名、照片、六卡内容、色彩、位置与时长。
2. 执行 `node scripts/build.mjs`，同步预览、组合镜头和时间线。
3. 执行 `npm run check`；通过后用 `npm run render -- --output 新版本.mp4 --fps 30 --quality delivery` 导出。

需要 Node.js；首次执行 check/render 会由 npx 下载 package.json 固定的 HyperFrames 版本。
`compositions/index.html` 可挂载到其他工程，保留整个 assets 目录和唯一 compositionId。
阅读停留至少0.8秒；当前为1.4秒。照片按原图使用，裁切由配置控制。
这是祖仁泽的个人镜头复刻工程。参考录屏、制作日志和本机路径不在此源包中。
