import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const configPath = process.argv[2] ? path.resolve(process.cwd(), process.argv[2]) : path.join(project, 'config.json');
const c = JSON.parse(fs.readFileSync(configPath, 'utf8'));
if (!(c.durationSeconds >= 3.2 && c.durationSeconds <= 30)) throw new Error('durationSeconds must be between 3.2 and 30');
if (!(c.holdSeconds >= 0.8 && c.holdSeconds < c.durationSeconds - 1.4)) throw new Error('holdSeconds must allow at least 1.4 seconds of motion');
if (c.width !== 1920 || c.height !== 1080) throw new Error('This authored layout is 1920x1080');
if (!Array.isArray(c.cards) || c.cards.length !== 6) throw new Error('This fan layout requires six cards');
if (!/^[a-z][a-z0-9-]*$/.test(c.compositionId)) throw new Error('compositionId must be a safe lowercase stable id');
for (const color of Object.values(c.palette)) if (!/^#[a-fA-F0-9]{6}$/.test(color)) throw new Error('Palette values must be six-digit hex');
if (path.isAbsolute(c.portrait) || c.portrait.includes('..') || !fs.existsSync(path.join(project,c.portrait))) throw new Error('portrait must exist inside the project');
const escape = s => String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const id=c.compositionId;
const variables = [
  {id:'personName',type:'string',label:'姓名',default:c.name,maxLength:8},
  {id:'personOrigin',type:'string',label:'籍贯',default:c.origin,maxLength:16},
  {id:'personCaption',type:'string',label:'开场短句',default:c.caption,maxLength:22},
  {id:'portraitSource',type:'string',label:'本人照片',default:c.portrait},
  ...c.cards.map((card,i)=>({id:`card${i+1}Title`,type:'string',label:`纸卡 ${i+1} 标题`,default:card.title,maxLength:5})),
  ...c.cards.map((card,i)=>({id:`card${i+1}Label`,type:'string',label:`纸卡 ${i+1} 关键词`,default:card.label,maxLength:20})),
  {id:'background',type:'color',label:'背景',default:c.palette.background},
  {id:'ink',type:'color',label:'文字',default:c.palette.ink},
  {id:'accent',type:'color',label:'强调',default:c.palette.accent}
];
const cards = c.cards.map((card,i)=>`
        <article id="${id}-paper-${i+1}" class="paper" data-layout-allow-overlap="true" style="z-index:${10+i};">
          <div class="paper-masthead"><span>人生切片</span><span>${String(i+1).padStart(2,'0')} / 06</span></div>
          <div class="paper-rule"></div>
          <h2 data-var-text="card${i+1}Title" class="${card.title.length>2?'wide-title':''}">${escape(card.title)}</h2>
          <p class="paper-label" data-var-text="card${i+1}Label">${escape(card.label)}</p>
          <div class="paper-columns" aria-hidden="true"><div></div><div></div></div>
          <div class="paper-seal" aria-hidden="true" data-layout-ignore="true">${String(i+1).padStart(2,'0')}</div>
          <div class="paper-footer" aria-hidden="true"></div>
        </article>`).join('');

function html(prefix='') {
const declared = variables.map(v=> v.id==='portraitSource'? {...v,default:prefix+c.portrait}:v);
return `<!doctype html>
<html lang="zh-CN" data-composition-variables='${escape(JSON.stringify(declared))}'>
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>祖仁泽 · 六页经历</title>
<style>
@font-face{font-family:StorySans;src:url('${prefix}assets/StorySans.ttf') format('truetype');font-display:block;font-weight:100 900}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden}
body{font-family:StorySans,sans-serif;background:${c.palette.background}}
#stage{position:relative;width:100%;height:100%;overflow:hidden;--background:${c.palette.background};--ink:${c.palette.ink};--accent:${c.palette.accent};--paper:${c.palette.paper};color:var(--ink)}
.clip{position:absolute;inset:0;width:100%;height:100%}
.background{position:absolute;inset:0;background:var(--background)}
.scene-content{position:relative;display:flex;flex-direction:column;width:100%;height:100%;padding:80px 90px 90px;gap:24px}
.identity{display:flex;flex-direction:column;align-items:flex-start;height:215px;flex:none;gap:12px;z-index:40}
.kicker{display:flex;align-items:center;gap:12px;font-size:18px;line-height:1.2;letter-spacing:4px}
.kicker-dot{display:block;width:12px;height:12px;border-radius:50%;background:var(--accent)}
.name-row{display:flex;align-items:baseline;gap:34px;flex-wrap:nowrap}
h1{margin:0;font-size:112px;font-weight:800;line-height:1.15;letter-spacing:8px;white-space:nowrap}
.origin{margin:0;font-size:32px;line-height:1.4;white-space:nowrap;border-left:2px solid var(--ink);padding-left:28px}
.caption{font-size:25px;margin:0;line-height:1.4;letter-spacing:3px}
.body-layout{display:grid;grid-template-columns:550px 1fr;gap:84px;min-height:0;flex:1;align-items:end}
.portrait-zone{height:100%;display:flex;align-items:flex-end;position:relative;z-index:35}
.portrait-frame{width:550px;height:620px;background:var(--paper);padding:16px 16px 76px;box-shadow:0 12px 32px rgb(32 54 59 / 15%);position:relative;transform-origin:50% 80%;will-change:transform,opacity}
.portrait-window{width:100%;height:100%;overflow:hidden;background:var(--ink)}
.portrait-window img{display:block;width:100%;height:100%;object-fit:cover;object-position:${escape(c.portraitPosition)};}
.portrait-caption{position:absolute;bottom:21px;left:24px;right:24px;display:flex;align-items:baseline;justify-content:space-between;line-height:1.1;font-size:18px;letter-spacing:2px}
.portrait-caption strong{font-size:25px;color:var(--accent)}
.fan{position:relative;width:100%;height:100%;min-height:620px;z-index:20}
.circle-wrap{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:0}
.circle{flex:none;width:835px;height:835px;background:var(--accent);opacity:.13;border-radius:50%;will-change:transform,opacity}
.paper{position:absolute;left:50%;top:50%;width:268px;height:352px;padding:20px 20px 16px;background:var(--paper);border:1px solid rgb(32 54 59 / 22%);box-shadow:0 9px 23px rgb(32 54 59 / 15%);display:flex;flex-direction:column;transform-origin:50% 90%;will-change:transform,opacity}
.paper-masthead{display:flex;justify-content:space-between;font-size:12px;line-height:1.1;letter-spacing:1px;white-space:nowrap}
.paper-rule{height:3px;background:var(--ink);margin:10px 0 28px;flex:none}
.paper h2{font-size:53px;line-height:1.15;margin:0;font-weight:800;letter-spacing:5px;white-space:nowrap;width:max-content;max-width:100%;align-self:flex-start}
.paper h2.wide-title{font-size:40px;letter-spacing:1px;line-height:1.52}
.paper-label{font-size:18px;margin:12px 0 14px;line-height:1.25;letter-spacing:0;white-space:nowrap}
.paper-columns{display:grid;grid-template-columns:1fr 1fr;gap:12px;height:65px;margin:0 0 10px;opacity:.20}
.paper-columns div{background:repeating-linear-gradient(to bottom,var(--ink) 0,var(--ink) 2px,transparent 2px,transparent 9px)}
.paper-seal{align-self:flex-end;font-size:40px;line-height:1;letter-spacing:1px;color:var(--accent);margin-top:3px}
.paper-footer{margin-top:auto;display:flex;justify-content:space-between;gap:10px;border-top:1px solid var(--ink);padding-top:8px;font-size:12px;line-height:1.2;white-space:nowrap}
</style>
</head>
<body>
<div id="stage" data-composition-id="${id}" data-start="0" data-duration="${c.durationSeconds}" data-fps="${c.fps}" data-width="${c.width}" data-height="${c.height}">
  <div class="background"></div>
  <section id="${id}-scene" class="clip" data-start="0" data-duration="${c.durationSeconds}" data-track-index="0">
    <div class="scene-content">
      <header class="identity">
        <div id="${id}-kicker" class="kicker"><span class="kicker-dot"></span><span>一个人，很多面</span></div>
        <div class="name-row"><h1 id="${id}-name" data-var-text="personName">${escape(c.name)}</h1><p id="${id}-origin" class="origin" data-var-text="personOrigin">${escape(c.origin)}</p></div>
        <p id="${id}-caption" class="caption" data-var-text="personCaption">${escape(c.caption)}</p>
      </header>
      <div class="body-layout">
        <div class="portrait-zone">
          <div id="${id}-portrait" class="portrait-frame">
            <div class="portrait-window"><img id="${id}-photo" src="${prefix}${escape(c.portrait)}" data-var-src="portraitSource" alt="祖仁泽本人真实照片"></div>
            <div class="portrait-caption"><strong data-var-text="personName">${escape(c.name)}</strong><span data-var-text="personOrigin">${escape(c.origin)}</span></div>
          </div>
        </div>
        <div class="fan" data-layout-allow-overlap="true">
          <div class="circle-wrap" aria-hidden="true"><div id="${id}-circle" class="circle"></div></div>
${cards}
        </div>
      </div>
    </div>
  </section>
</div>
<script src="${prefix}assets/gsap.min.js"></script>
<script>
// All times derive from the generated root duration; final hold remains literal seconds.
const cfg = ${JSON.stringify({duration:c.durationSeconds,hold:c.holdSeconds,cards:c.cards.map(({x,y,rotation})=>({x,y,rotation}))})};
const motionScale=(cfg.duration-cfg.hold)/4.8;
const t=n=>n*motionScale;
const tl=gsap.timeline({paused:true});
tl.fromTo('#${id}-kicker',{opacity:0,x:-18},{opacity:1,x:0,duration:t(.25),ease:'power2.out'},t(.16));
tl.fromTo('#${id}-name',{opacity:0,y:52},{opacity:1,y:0,duration:t(.72),ease:'expo.out'},t(.22));
tl.fromTo('#${id}-origin',{opacity:0,x:25},{opacity:1,x:0,duration:t(.45),ease:'power1.out'},t(.48));
tl.fromTo('#${id}-caption',{opacity:0},{opacity:1,duration:t(.34),ease:'sine.out'},t(.83));
tl.fromTo('#${id}-portrait',{opacity:0,x:-100,y:25,rotation:-10,scale:.9},{opacity:1,x:0,y:0,rotation:-3,scale:1,duration:t(1.18),ease:'power4.out'},t(.64));
tl.fromTo('#${id}-circle',{scale:0,opacity:0},{scale:1,opacity:.13,duration:t(1.75),ease:'circ.out'},t(1.88));
const entryEases=['power3.out','expo.out','power4.out','power3.out','expo.out','power4.out'];
cfg.cards.forEach((pose,i)=>{
  tl.fromTo('#${id}-paper-'+(i+1),
    {xPercent:-50,yPercent:-50,x:-50,y:155,scale:.20,rotation:12-i*5,opacity:0},
    {x:pose.x,y:pose.y,scale:1,rotation:pose.rotation,opacity:1,duration:t(1.4),ease:entryEases[i]},
    t(2.99+i*.082));
});
window.__timelines=window.__timelines||{};
window.__timelines['${id}']=tl;
tl.seek(0);
</script>
</body>
</html>`;
}
fs.mkdirSync(path.join(project,'compositions'),{recursive:true});
fs.writeFileSync(path.join(project,'index.html'),html());
// HyperFrames serves sub-compositions against the project root, including in Studio.
fs.writeFileSync(path.join(project,'compositions','index.html'),html());
const plan=JSON.parse(fs.readFileSync(path.join(project,'shot-plan.json'),'utf8'));
plan.duration_s=c.durationSeconds;plan.fps=c.fps;plan.content.scenes[0].end=c.durationSeconds;
plan.proof_times_s=[0,1.2*(c.durationSeconds-c.holdSeconds)/4.8,3.3*(c.durationSeconds-c.holdSeconds)/4.8,c.durationSeconds-c.holdSeconds,c.durationSeconds-1/c.fps].map(n=>Number(n.toFixed(6)));
fs.writeFileSync(path.join(project,'shot-plan.json'),JSON.stringify(plan,null,2)+'\n');
fs.writeFileSync(path.join(project,'build-manifest.json'),JSON.stringify({compositionId:id,durationSeconds:c.durationSeconds,fps:c.fps,frames:Math.round(c.durationSeconds*c.fps),width:c.width,height:c.height,holdSeconds:c.holdSeconds,entry:'index.html',mountableEntry:'compositions/index.html',audio:false,config:path.basename(configPath)},null,2)+'\n');
fs.writeFileSync(path.join(project,'index.motion.json'),JSON.stringify({duration:c.durationSeconds,assertions:[
  {kind:'appearsBy',selector:'#'+id+'-name',bySec:0.55*(c.durationSeconds-c.holdSeconds)/4.8},
  {kind:'appearsBy',selector:'#'+id+'-portrait',bySec:1.5*(c.durationSeconds-c.holdSeconds)/4.8},
  ...c.cards.map((_,i)=>({kind:'appearsBy',selector:'#'+id+'-paper-'+(i+1)+' h2',bySec:c.durationSeconds-c.holdSeconds})),
  ...c.cards.map((_,i)=>({kind:'staysInFrame',selector:'#'+id+'-paper-'+(i+1)+' h2'}))
]},null,2)+'\n');
console.log(`Built ${id}: ${c.width}x${c.height}, ${c.durationSeconds}s, ${Math.round(c.durationSeconds*c.fps)} frames; final hold ${c.holdSeconds}s`);
