import {AbsoluteFill,Composition,staticFile} from 'remotion';
import {loadFont} from '@remotion/fonts';
import {StrengthWords,INK} from './Motion';
import config from '../config.json';
loadFont({family:'Ink',url:staticFile('assets/Ink.ttf')});
const Shot=()=> <AbsoluteFill style={{background:INK}}><StrengthWords {...config}/></AbsoluteFill>;
export const Root=()=> <Composition id="StrengthWords" component={Shot} width={1080} height={1920} fps={30} durationInFrames={Math.round(config.duration*30)}/>;
