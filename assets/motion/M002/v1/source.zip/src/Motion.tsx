import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

export const INK='#111b1b';
export const GOLD='#eccb87';
export const PAPER='#f6f0e4';

type WordsProps={top:string;bottom:string;eyebrow?:string;duration?:number;standalone?:boolean};
/** Same reusable motion node is used in the film and independent motion export. */
export const StrengthWords:React.FC<WordsProps>=({top,bottom,eyebrow='',duration=3,standalone=false})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 const fade=interpolate(frame,[0,5,duration*fps-9,duration*fps-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{background:standalone?INK:undefined,fontFamily:'Ink',justifyContent:'flex-start',pointerEvents:'none',opacity:fade}}>
  <div style={{position:'absolute',left:84,right:84,top:standalone?680:1190}}>
   {eyebrow&&<div style={{fontFamily:'Arial, "PingFang SC", sans-serif',fontSize:30,letterSpacing:8,color:GOLD,marginBottom:20,opacity:interpolate(frame,[0,8],[0,1],{extrapolateRight:'clamp'})}}>{eyebrow}</div>}
   <div style={{color:PAPER,fontSize:top.length>10?64:94,lineHeight:1.12,textShadow:'0 4px 20px #000',translate:`0px ${interpolate(frame,[0,16],[75,0],{easing:Easing.bezier(.16,1,.3,1),extrapolateRight:'clamp'})}px`,opacity:interpolate(frame,[0,10],[0,1],{extrapolateRight:'clamp'})}}>{top}</div>
   <div style={{color:GOLD,fontSize:126,lineHeight:1.15,marginTop:18,textShadow:'0 5px 25px #000',translate:`${interpolate(frame,[5,23],[95,0],{easing:Easing.bezier(.16,1,.3,1),extrapolateLeft:'clamp',extrapolateRight:'clamp'})}px 0px`,opacity:interpolate(frame,[5,15],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>{bottom}</div>
   <svg width="850" height="38" style={{marginTop:6,overflow:'visible'}}><path d="M8 18 Q230 4 470 19 Q650 27 822 7" stroke={GOLD} strokeWidth="9" fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1-interpolate(frame,[12,33],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/></svg>
  </div>
 </AbsoluteFill>;
};

