import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const path=new URL('../public/assets/Ink.ttf',import.meta.url);
const expected='6d2546bb189c732a8ca29af9e22457b152387d158aa459e4ac2ce1e51788b7fb';
const hash=b=>createHash('sha256').update(b).digest('hex');
try {if(hash(await readFile(path))===expected){console.log('Font verified');process.exit(0)}} catch {}
const response=await fetch('https://raw.githubusercontent.com/google/fonts/main/ofl/mashanzheng/MaShanZheng-Regular.ttf');
if(!response.ok)throw new Error('Font download failed: '+response.status);
const bytes=Buffer.from(await response.arrayBuffer());
if(hash(bytes)!==expected)throw new Error('Official font hash differs; review before using');
await mkdir(new URL('../public/assets/',import.meta.url),{recursive:true});await writeFile(path,bytes);console.log('Official OFL font downloaded and verified');
