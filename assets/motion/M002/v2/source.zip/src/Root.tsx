import {AbsoluteFill,Composition,staticFile,useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/fonts';
import {StrengthWords,INK} from './Motion';
import config from '../config.json';
loadFont({family:'Ink',url:staticFile('assets/Ink.ttf')});
const Shot=()=> {const {width}=useVideoConfig();return <AbsoluteFill style={{background:INK}}><div style={{position:'absolute',width:1080,height:1920,transform:`scale(${width/1080})`,transformOrigin:'top left'}}><StrengthWords {...config}/></div></AbsoluteFill>;};
export const Root=()=> <Composition id="StrengthWords" component={Shot} width={2160} height={3840} fps={30} durationInFrames={Math.round(config.duration*30)}/>;
