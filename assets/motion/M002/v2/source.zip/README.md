# M002｜力量金句 · 书法点题

9:16，2160×3840，30fps，2.6秒。预览是V004《给你力量》第二版8.9–11.5秒的实际采用画面，移除音轨便于复用。人物背景、整条口播、其他影视片段不包含在源包中；本工程导出深墨底的独立文字层示例。

## 修改与导出

1. 使用Node.js，运行 `npm install`、`npm run fonts`。
2. 修改 `config.json`：top为铺垫，bottom为主观点，eyebrow为小标签，duration为秒数。默认在画面下半部；standalone=true将文字移到居中展示位置。
3. `npm run start`预览；`npm run check`检查；`npm run render`导出M002.mp4。
4. 接入其他Remotion影片时导入 `StrengthWords`，放进2.6秒的Sequence，保持Ink字体注册。函数按帧运行，位移、透明度和笔触依次推进，无CSS定时动画。

预览中的文字运动来自同一组件：0–10帧铺垫上移淡入，5–23帧金句从右侧落位，12–33帧笔触展开，末尾9帧淡出。已在V004多处重复使用。

Ink字体为Google Fonts官方Ma Shan Zheng，SIL Open Font License 1.1；许可证在licenses。首次prepare-fonts从官方仓库下载并核验SHA-256，之后可离线使用。本源包小标签使用系统无衬线字体，未分发私有系统字体。预览仅用于展示实际已采用镜头，不等于人物视频源素材。

4K版在1080×1920设计坐标上用Remotion实际绘制到2160×3840画布；文字动效与第一版相同，源包不含人物口播录像。预览取自已验证的第二版最终MP4；原人物素材分辨率为544×960。
